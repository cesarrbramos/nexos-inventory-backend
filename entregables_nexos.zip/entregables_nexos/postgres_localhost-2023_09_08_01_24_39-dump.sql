--
-- PostgreSQL database dump
--

-- Dumped from database version 12.16
-- Dumped by pg_dump version 12.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Spanish_Colombia.1252' LC_CTYPE = 'Spanish_Colombia.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    name character varying,
    quantity integer,
    entry_date date,
    create_user_id bigint,
    update_user_id bigint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: TABLE products; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.products IS 'Tabla de productos';


--
-- Name: COLUMN products.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.products.name IS 'Nombre del producto';


--
-- Name: COLUMN products.quantity; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.products.quantity IS 'Cantidad';


--
-- Name: COLUMN products.create_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.products.create_user_id IS 'Usuario creador';


--
-- Name: COLUMN products.update_user_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.products.update_user_id IS 'Usuario modificador';


--
-- Name: COLUMN products.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.products.created_at IS 'Fecha creación';


--
-- Name: COLUMN products.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.products.updated_at IS 'Fecha modificación';


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.roles IS 'Tabla de cargos';


--
-- Name: COLUMN roles.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.roles.name IS 'Nombre del producto';


--
-- Name: COLUMN roles.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.roles.created_at IS 'Fecha de creación';


--
-- Name: COLUMN roles.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.roles.updated_at IS 'Fecha de actualización';


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    firstname character varying(100),
    lastname character varying(100),
    birth_date date NOT NULL,
    entry_date date NOT NULL,
    role_id bigint,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.users IS 'Tabla de usuarios';


--
-- Name: COLUMN users.firstname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.firstname IS 'Nombres';


--
-- Name: COLUMN users.lastname; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.lastname IS 'Apellidos';


--
-- Name: COLUMN users.birth_date; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.birth_date IS 'Fecha de nacimiento';


--
-- Name: COLUMN users.role_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.role_id IS 'Cargo';


--
-- Name: COLUMN users.created_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.created_at IS 'Fecha de creación';


--
-- Name: COLUMN users.updated_at; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.users.updated_at IS 'Fecha de actualización';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (1, 'Aceite de Motor', 200, '2023-09-05', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (2, 'Filtro de Aceite', 150, '2023-09-06', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (3, 'Batería de Automóvil', 100, '2023-09-07', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (4, 'Pastillas de Freno', 300, '2023-09-08', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (5, 'Llantas para Automóvil', 50, '2023-09-09', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (6, 'Anticongelante', 80, '2023-09-10', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (7, 'Filtro de Aire', 200, '2023-09-11', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (8, 'Aceite de Transmisión', 120, '2023-09-12', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (9, 'Limpiaparabrisas', 180, '2023-09-13', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (10, 'Bombilla de Faro', 250, '2023-09-14', 1, 1, '2023-09-06 02:23:53.166074', '2023-09-06 02:23:53.166074');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (14, 'Aceite liquido de frenos', 20, '2023-09-07', 1, 1, '2023-09-07 00:57:54.025', '2023-09-07 00:57:54.025');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (16, 'Pruebas', 1, '2023-10-08', 1, 1, '2023-09-07 22:20:54.478', '2023-09-07 22:20:54.478');
INSERT INTO public.products (id, name, quantity, entry_date, create_user_id, update_user_id, created_at, updated_at) VALUES (17, 'Pruebas producto', 1, '2023-10-22', 1, 1, '2023-09-07 22:31:30.314', '2023-09-07 22:31:30.314');


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.roles (id, name, created_at, updated_at) VALUES (1, 'Administrador', '2023-09-05 21:19:34', '2023-09-05 21:19:39');


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.users (id, firstname, lastname, birth_date, entry_date, role_id, created_at, updated_at) VALUES (1, 'CESAR', 'BOLAÑO', '2001-11-24', '2023-01-10', 1, '2023-09-05 21:18:15', '2023-09-05 21:18:18');
INSERT INTO public.users (id, firstname, lastname, birth_date, entry_date, role_id, created_at, updated_at) VALUES (3, 'PRUEBA', 'TEC', '1996-09-20', '2023-01-01', 1, '2023-09-05 21:18:15', '2023-09-05 21:18:18');


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 20, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: products products_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pk PRIMARY KEY (id);


--
-- Name: roles roles_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pk PRIMARY KEY (id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- Name: products products__create_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products__create_user_fk FOREIGN KEY (create_user_id) REFERENCES public.users(id);


--
-- Name: products products__update_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products__update_user_fk FOREIGN KEY (update_user_id) REFERENCES public.users(id);


--
-- Name: users users_roles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_roles_id_fk FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: CONSTRAINT users_roles_id_fk ON users; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON CONSTRAINT users_roles_id_fk ON public.users IS 'Relacion roles';


--
-- PostgreSQL database dump complete
--

